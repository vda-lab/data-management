---
title: Tables and rows vs collections and documents
keywords: nosql
sidebar: nosql_sidebar
toc: false
permalink: nosql-document-databases-collections-and-documents.html
folder: nosql
---
{% include custom/series_nosql_previous.html %}



{% include custom/series_nosql_next.html %}
