# course-template

This template can be used to create new courses. It's based on idratherbewriting at https://idratherbewriting.com/documentation-theme-jekyll/#
